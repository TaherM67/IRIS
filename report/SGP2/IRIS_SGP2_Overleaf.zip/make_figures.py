"""Rebuild report graphics directly from the saved Colab evaluation metadata."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'Evidence'
if not EVIDENCE.exists():
    EVIDENCE = (ROOT / '../../artifacts/user_colab_run/models').resolve()
META = json.loads((EVIDENCE / 'metadata.json').read_text())
FIG = ROOT / 'Figures'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size': 12, 'font.family': 'DejaVu Sans', 'axes.spines.top': False,
                     'axes.spines.right': False, 'savefig.bbox': 'tight'})
NAVY, TEAL, GOLD = '#19364b', '#128575', '#c28b24'

def save(fig, name):
    fig.savefig(FIG / (name + '.pdf'))
    plt.close(fig)

def flow(name, boxes, links, size=(10, 6)):
    fig, ax = plt.subplots(figsize=size)
    ax.set(xlim=(0, 10), ylim=(-.2, 7)); ax.axis('off')
    for key, (x, y, text) in boxes.items():
        ax.add_patch(FancyBboxPatch((x-1.35,y-.46),2.7,.92,boxstyle='round,pad=.08',facecolor='#edf5f5',edgecolor=TEAL))
        ax.text(x,y,text,ha='center',va='center',fontsize=13,color=NAVY)
    for a,b in links:
        x,y,_=boxes[a]; u,v,_=boxes[b]
        dy = -.53 if v<y else .53 if v>y else 0
        dx = 1.45 if u>x and v==y else -1.45 if u<x and v==y else 0
        ax.annotate('',xy=(u-dx,v-dy),xytext=(x+dx,y+dy),arrowprops={'arrowstyle':'->','color':NAVY,'lw':1.2})
    save(fig,name)

flow('architecture', {
 'a':(1.55,6.3,'Asset inventory\nJSON'), 'r':(5,6.3,'Risk register\nJSON'), 's':(8.45,6.3,'SIEM alerts\nJSONL'),
 'j':(5,4.8,'Shared integration\nValidate + enrich'),
 'f':(5,3.3,'Session features\nRules + ML shadow'),
 'p':(5,1.8,'Risk/priority policy\nSaved review proposals'),
 'h':(1.55,.5,'SOC / GRC\nowning-team approval'), 'd':(5,.5,'SQLite working records\nChanges + audit'),
 'u':(8.45,.5,'Admin monitoring\nCurrent-state exports')},
 [('a','j'),('r','j'),('s','j'),('j','f'),('f','p'),('p','h'),('h','d'),('d','u')])
flow('learning', {
 'x':(5,6.2,'Integrated sessions\nOffline labels separate'),
 'm1':(2,4.7,'Model 1: scenario\nCalibrated random forest'),
 'm2':(8,4.7,'Model 2: control advice\nBinary logistic models'),
 'r':(2,2.9,'Frozen primary rules\nIndependent of ML'),
 'c':(8,2.9,'ML candidates\nShadow comparisons only'),
 'p':(5,1.1,'Explicit risk policy\nHuman-approved demo writes')},
 [('x','m1'),('x','m2'),('m1','m2'),('m1','c'),('m2','c'),('r','p')])

fig,ax=plt.subplots(figsize=(8.6,3.4))
names=['Fit','Selection','Calibration','Threshold','Test']; vals=[450,135,90,90,135]
bars=ax.barh(names[::-1], vals[::-1],color=[TEAL,NAVY,GOLD,'#73989b','#355e7a'][::-1])
for b in bars: ax.text(b.get_width()+7,b.get_y()+b.get_height()/2,f'{int(b.get_width())} sessions',va='center')
ax.set(xlim=(0,575),xlabel='Sessions (900 total; campaign-disjoint partitions)'); save(fig,'splits')

fig,axs=plt.subplots(1,2,figsize=(9,4))
for ax,key,title in zip(axs,['metrics','rule_baseline'],['Model 1','Frozen rule baseline']):
    cm=np.array(META['model1'][key]['confusion_matrix'])[:3,:]
    ax.imshow(cm,cmap='Blues',vmin=0,vmax=45)
    for i in range(3):
        for j in range(4): ax.text(j,i,str(cm[i,j]),ha='center',va='center',color='white' if cm[i,j]>22 else NAVY)
    ax.set(xticks=range(4),xticklabels=['Benign','Credential','Recon.','Abstain'],yticks=range(3),yticklabels=['Benign','Credential','Recon.'],title=title,xlabel='Predicted class',ylabel='True class')
    ax.tick_params(axis='x',labelrotation=25)
fig.tight_layout(); save(fig,'confusion')

fig,ax=plt.subplots(figsize=(8.6,3.6))
labels=['Accuracy\n(all sessions)','Macro-F1','Coverage','Benign false-\npositive rate']; x=np.arange(4)
for delta,key,color,name in [(-.18,'metrics',TEAL,'Model 1'),(.18,'rule_baseline',NAVY,'Frozen rules')]:
    v=[META['model1'][key][k]*100 for k in ['accuracy_all_sessions','macro_f1','coverage','benign_false_positive_rate']]
    bars=ax.bar(x+delta,v,.34,label=name,color=color)
    for b in bars: ax.text(b.get_x()+b.get_width()/2,b.get_height()+1,f'{b.get_height():.1f}',ha='center',fontsize=10)
ax.set(xticks=x,xticklabels=labels,ylim=(0,116),ylabel='Percent (FPR: lower is better)'); ax.legend(loc='upper left',ncols=2); save(fig,'model1_comparison')

fig,axs=plt.subplots(1,2,figsize=(9,3.4))
supported=[k for k,v in META['model2']['support'].items() if v['test_positive']]
v=[META['model2']['metrics']['per_control'][k]['f1'] for k in supported]
axs[0].bar(supported,v,color=TEAL); axs[0].set(ylim=(0,1.15),ylabel='Per-control F1',title='Six controls with positive test support')
axs[1].bar(['Positive test\nsupport','No positive\ntest support'],[6,24],color=[TEAL,'#aebbc4']); axs[1].set(ylim=(0,30),ylabel='Catalogue controls',title='Coverage is limited, despite high micro-F1')
fig.tight_layout(); save(fig,'control_coverage')

fig,axs=plt.subplots(1,2,figsize=(9,3.2))
axs[0].bar(['Before','After GRC\napproval'],[.6,.8],color=[NAVY,TEAL]); axs[0].set(ylim=(0,1),ylabel='Normalized risk score'); axs[0].set_title('Same registered risk; impact stays 5')
axs[1].bar(['Changed to\nCritical','Already Critical\nunchanged'],[19,10],color=[TEAL,'#aebbc4']); axs[1].set(ylim=(0,32),ylabel='Alerts in the same session'); axs[1].set_title('29 alerts; 19 actual priority writes')
fig.tight_layout(); save(fig,'approval_results')

fig,ax=plt.subplots(figsize=(9,3.1))
tasks=['Source contracts','Model evaluation','Approval backend','Role interfaces','Regression testing','Examiner rehearsal']
starts=[1,3,5,7,8,11]; lengths=[3,4,4,3,4,2]
for i,(s,l) in enumerate(zip(starts,lengths)): ax.barh(i,l,left=s-.5,height=.55,color=TEAL if i<5 else GOLD)
ax.set(yticks=range(6),yticklabels=tasks,xticks=range(1,13),xlim=(.5,12.5),xlabel='Relative implementation week (proposed sequence, not historical dates)'); ax.invert_yaxis(); ax.grid(axis='x',alpha=.2); save(fig,'gantt')

grid=json.loads((EVIDENCE/'threshold_search.json').read_text())
fig,ax=plt.subplots(figsize=(8.6,3.3))
for metric,label,color in [('coverage','Coverage',NAVY),('macro_f1','Macro-F1',TEAL),('benign_false_positive_rate','Benign FPR',GOLD)]:
    ax.plot([g['threshold'] for g in grid],[g['metrics'][metric]*100 for g in grid],label=label,color=color,marker='.',lw=1.4)
ax.axvline(.5,color='#8a5961',ls='--',label='Selected threshold 0.50'); ax.set(xlabel='Confidence threshold',ylabel='Percent',ylim=(0,105)); ax.legend(ncols=2,fontsize=10); save(fig,'thresholds')
